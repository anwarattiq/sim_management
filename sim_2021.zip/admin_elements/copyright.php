<div class="footer text-muted">&copy; <?php echo date('Y');?>. All rights reserved.</div>
